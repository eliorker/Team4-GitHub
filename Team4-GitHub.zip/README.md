# Team4-GitHub
Welcome to CV4U CLI
Options Are available:
Login:
python cli.py login --username youruser --password yourpassword
Register:
python cli.py register --username youruser --password yourpass --email email --acctype 0/1
Add:
python cli.py add --path yourcvfile.json 
Filter:
python cli.py filter // filtering all candidate if acctype is 1 !

Mysql : 
cv4u.sql 
